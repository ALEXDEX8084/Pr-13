﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Pr13Melega
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Практическая работа №13");
            Console.WriteLine("Выполнил студент группы ИСП.20А");
            Console.WriteLine("Мелега Алексей");
            string input = @"Input.txt";
            double T = 330;
            double m = 3.35e-27;
            double k = 1.38e-21;
            StreamWriter sw = new StreamWriter(input, false);
            sw.WriteLine(T);
            sw.WriteLine(m);
            sw.WriteLine(k);
            sw.Close();
            Console.WriteLine("Запись произведена");
            Console.ReadKey();
            StreamReader sr = new StreamReader(input);           
            double T_in = Convert.ToDouble(sr.ReadLine());
            double m_in = Convert.ToDouble(sr.ReadLine());
            double k_in = Convert.ToDouble(sr.ReadLine());
            Console.WriteLine("Считывание завершенно");           
            Console.WriteLine("Исходные данные:");
            Console.WriteLine($"T = {T_in}");
            Console.WriteLine($"m = {m_in}");
            Console.WriteLine($"k = {k_in}");
            double V = Math.Sqrt((3 * k_in * T_in) / m_in);
            string output = @"Output.txt";
            StreamWriter sw1 = new StreamWriter(output, false);
            sw1.WriteLine(V);
            sw1.Close();
            Console.WriteLine($"Результат: V = {V}");
            Console.WriteLine("Запись завершенна");
            Console.ReadKey();
        }
    }
}
