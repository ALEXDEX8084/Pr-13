﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Рылеев_ПР11.Pages
{
    /// <summary>
    /// Логика взаимодействия для Page1.xaml
    /// </summary>
    public partial class Page1 : Page
    {
        int[] Z = new int[35];

        public Page1()
        {
            InitializeComponent();
        }

        private void btnCreate_Click(object sender, RoutedEventArgs e)
        {
            lstInput.Items.Clear();
            Random Rand = new Random();
            for (int i = 0; i < 35; i++)
            {
                Z[i] = Rand.Next(-50, 10);
                lstInput.Items.Add(new ListViewItem { Content = $"{i + 1})    Z[{i}] = {Z[i]}" });
            }
            btnCreate.Content = "Пересоздать массив";
            txbResult1.Text = "S = ";
            txbResult2.Text = "P = ";
            txbResult3.Text = "R = ";
            S.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#e2e8e4"));
            P.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#e2e8e4"));
            R.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#e2e8e4"));
            S.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#006C84"));
            P.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#006C84"));
            R.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#006C84"));
            S.FontWeight = FontWeights.Normal;
            P.FontWeight = FontWeights.Normal;
            R.FontWeight = FontWeights.Normal;
        }

        private void btnResult_Click(object sender, RoutedEventArgs e)
        {
            if (lstInput.Items.Count > 0)
            {
                int R = 0;
                int S = 0;
                int P = 1;
                for (int i = 0; i < 35; i++)
                {
                    if (Z[i] % 2 == 0 && Z[i] < 3)
                    {
                        S += Z[i];
                    }
                    if (Z[i] % 2 != 0 && Z[i] > 1)
                    {
                        P *= Z[i];
                    }
                }
                R = S + P;
                txbResult1.Text = $"S = {S}";
                txbResult2.Text = $"P = {P}";
                txbResult3.Text = $"R = {R}";
            }
        }

        private void btnClearAll_Click(object sender, RoutedEventArgs e)
        {
            lstInput.Items.Clear();
            txbResult1.Text = "";
            txbResult2.Text = "";
            txbResult3.Text = "";
            btnCreate.Content = "Cоздать массив";
            S.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#e2e8e4"));
            P.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#e2e8e4"));
            R.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#e2e8e4"));
            S.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#006C84"));
            P.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#006C84"));
            R.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#006C84"));
            S.FontWeight = FontWeights.Normal;
            P.FontWeight = FontWeights.Normal;
            R.FontWeight = FontWeights.Normal;
        }

        private void btnNext_Click(object sender, RoutedEventArgs e)
        {
            LstFrame.frmObject.Navigate(new Page2());
        }

        private void S_Click(object sender, RoutedEventArgs e)
        {
            if (lstInput.Items.Count > 0)
            {
                for (int i = 0; i < 35; i++)
                {
                    if (Z[i] % 2 == 0 && Z[i] < 3)
                    {
                        var Item = (ListBoxItem)lstInput.Items[i];
                        Item.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#00ff00"));
                        Item.FontWeight = FontWeights.Bold;
                    }
                }
                S.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#006C84"));
                S.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#00ff00"));
                S.FontWeight = FontWeights.Bold;
            }
        }

        private void P_Click(object sender, RoutedEventArgs e)
        {
            if (lstInput.Items.Count > 0)
            {
                for (int i = 0; i < 35; i++)
                {
                    if (Z[i] % 2 != 0 && Z[i] > 1)
                    {
                        var Item = (ListBoxItem)lstInput.Items[i];
                        Item.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ff4e33"));
                        Item.FontWeight = FontWeights.Bold;
                    }
                }
                P.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#006C84"));
                P.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ff4e33"));
                P.FontWeight = FontWeights.Bold;
            }
        }

        private void R_Click(object sender, RoutedEventArgs e)
        {
            if (lstInput.Items.Count > 0)
            {
                for (int i = 0; i < 35; i++)
                {
                    if (Z[i] % 2 == 0 && Z[i] < 3)
                    {
                        var Item = (ListBoxItem)lstInput.Items[i];
                        Item.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#6EB5C0"));
                        Item.FontWeight = FontWeights.Bold;
                    }
                    if (Z[i] % 2 != 0 && Z[i] > 1)
                    {
                        var Item = (ListBoxItem)lstInput.Items[i];
                        Item.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#6EB5C0"));
                        Item.FontWeight = FontWeights.Bold;
                    }
                }
                R.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#006C84"));
                R.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#e2e8e4"));
                R.FontWeight = FontWeights.Bold;
            }
        }
    }
}
