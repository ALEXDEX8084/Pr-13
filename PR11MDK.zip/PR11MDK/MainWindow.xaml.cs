﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PR11MDK
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            int[] myArray = new int[30];
            Random rand = new Random();
            for (int y = 0; y < 30; y++)
            {
                myArray[y] = rand.Next(-1000,1000);
            }
            for (int i = 0; i < 30; ++i)
                input1.Items.Add(myArray[i]);

        }
        private void Count_Click(object sender, RoutedEventArgs e)
        {
            string[] spp = new string[input1.Items.Count];
            for (int i = 0; i < spp.Length; i++)
                spp[i] = input1.Items[i].ToString();
            int[] pp = new int[30];
            for (int i = 0; i < 30; i++)
            {
                pp[i] = int.Parse(spp[i]);
            }
            int result = 0;
            for (int i = 0; i < 30; i++)
            {
                if (pp[i] % 2 != 0 && pp[i]<0)
                {
                    result = result + pp[i];
                }
                continue;
            }
            output1.Items.Add(result);
        }
    }
}
