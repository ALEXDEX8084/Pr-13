﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR15_16
{
    class PRICE
    {
        //поля класса
        private string name;
        private int cost;
        private string mname;
        private int kolvo;
        // свойства для доступа к полям
        public string TNAME
        {
            get { return name; }
            set { name = value; }
        }
        public int KOLVO
        {
            get { return kolvo; }
            set { kolvo = value; }
        }
        public int Cost
        {
            get { return cost; }
            set { cost = value; }
        }
        public string MNAME
        {
            get { return mname; }
            set { mname = value; }
        }
        //методы 
        //конструктор без параметров
        public PRICE()
        {
            cost = 100;
            mname = "Пяторочка";
            kolvo = 1000;

        }
        //конструктор с параметрами
        public PRICE(string f,
            int k, string g, int ph)
        {
            name = f;
            cost = k;
            mname = g;
            kolvo = ph;
        }
        //вывод информации об объекте
        public string PrintInfo()
        {
            return $" Название товара {name} " +
                $"Цена: {cost} " +
                $" Название магазина: {mname} " +
                $"Количество товара: {kolvo}";
        }
    }
}
